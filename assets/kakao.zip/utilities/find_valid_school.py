import re
import threading
from statistics import mode, StatisticsError
import difflib

MAX_WORD_LENGTH = 7



def find_index_sim(refined_comment,school_post_ptn):
    sch_pattern = re.compile(''.join(map(str, school_post_ptn)))
    valid_list = [''.join(map(str, sch_pattern.findall(cdt))) for cdt in refined_comment]
    return valid_list.index(school_post_ptn)

def add_pre_word(school_post_ptn,refined_comment):
    valid_index = find_index_sim(refined_comment, school_post_ptn)
    # candidates = [refined_comment[idx] for idx, val in enumerate(sch_excluded) if val == '']
    new_sch_name = school_post_ptn
    for val in range(min(valid_index,MAX_WORD_LENGTH)):
        new_sch_name = refined_comment[valid_index -1 - val] + new_sch_name
        if len(new_sch_name) > 15:
            break
    try:
        return new_sch_name
    except IndexError as e:
        raise('Not valid school name')

def remove_wrong_cha(school,wrong_ptn):
    # wrong_ptn = re.compile(''.join(map(str, [w + '|' for w in wrong_ptn]))+)
    wrong_ptn = re.compile(''.join(map(str, [w + '|' for w in wrong_ptn])))
    valid_word = wrong_ptn.sub('',school)
    wrong_ptn = re.compile('([ㄱ-ㅎㅏ-ㅣ]+)')
    valid_word = wrong_ptn.sub('',valid_word)
    return valid_word

def remove_basic_word(candidate,base_pattern,added):
    base_pattern = base_pattern + added
    wrong_ptn = re.compile(''.join(map(str, [w + '|' for w in base_pattern])))
    return wrong_ptn.sub('', candidate)


def top_one(candidates,base_pattern):
    try:#try a easy mode
        top_fre_one = mode(candidates)
        if top_fre_one != '':
            # print('222',top_fre_one)
            return [top_fre_one]
    except StatisticsError:
        pass
        # continue detail mode

    ref_candidates = [remove_basic_word(cdt,base_pattern,['고','등','대']) for cdt in candidates]
    #check subset relation between candidates
    ref_candidates = sorted(ref_candidates,key=len)


    #
    valid_candidate = []
    for ind, cdt in enumerate(ref_candidates):
        _pattern = re.compile(cdt)
        if ind < len(ref_candidates)-1:
            len_subset = len([_pattern.findall(ref_candidates[idx + ind + 1]) for idx in range(len(ref_candidates) - ind - 1)][0])
            subset = [_pattern.findall(ref_candidates[idx + ind + 1]) for idx in range(len(ref_candidates) - ind - 1)]
            if len_subset  == 0:
                valid_candidate.append(cdt)
            else:
                valid_candidate.append(ref_candidates[ind+1])

        else:
            valid_candidate.append(cdt)






    try:
        valid_candidate = [val for val in valid_candidate if val != '']


        close_one = mode(valid_candidate)


        wrong_ptn = re.compile('학교')
        ref_candidates = [wrong_ptn.sub('', cdt) for cdt in candidates]
        top_fre_one = difflib.get_close_matches(close_one, ref_candidates)


        _pattern = re.compile(top_fre_one[0])
        top_fre_one = [cdt for cdt in candidates if len(_pattern.findall(cdt)) > 0][-1]
        return [top_fre_one]
    except StatisticsError as e:
        #This exception means that the most related word about school is to be determined by reliable school pool
        return valid_candidate
    except IndexError as e:
        if close_one != '':
            top_ptn = re.compile(close_one)
            candidates = sorted([cdt for cdt in candidates if len(top_ptn.findall(cdt)) > 0],key=len)
            top_fre_one = candidates[-1]
            return [top_fre_one]
        else:
            print('this condition means that all the candidates are consisting of only the basic words')
            return candidates

def extend_postfix(school):
    if school[-1] in ['대','중']:
        school += '학교'
    elif school[-1] in ['고','초']:
        school += '등학교'
    elif school[-2:] in ['학우']:
        school = school[:-2]
        school  += '대학교'
    return school



def extract_(q):
    # sem.acquire()
    # try:

    while True:
        # if not q.empty():
        comment = q.get()
        if comment == 'STOP':
            break
        else:
            # print(comment)
            #한글만 추출
            com_korean = re.compile('[^ ㄱ-ㅣ가-힣]+')
            try:
                result = com_korean.sub(' ',comment)
                #한글만 추출
                base_pattern = ['학교', '여고', '남고', '여중', '남중', '중', '초', '학우']
                com_pattern = re.compile(''.join(map(str, ['\w+?' + b + '|' for b in base_pattern]))[:-1])

                # com_pattern = re.compile(r"\w+?학교|\w+?여고|\w+?남고|\w+?여중|\w+?남중|\w+?중|\w+?초|\w+?학우")

                basic_school = ['대학교','고등학교','중학교','초등학교','여대자학교','남자고등학교','여자고등학교','남자중학교',
                                '여자중학교','남고등학교','여고등학교','남중학교','여중학교','남자중','여자중','남중','여중']

                #processing list for exception
                excluded_word = ['저희학교','우리학교','파하고','남기고','우리고등학교','우리중학교','우리초등학교','등학교',
                                 '중고등학교','먹고','하고','까칠하고','배고','주신다고','말라가고','고소하고','먹고','꼭대기고',
                                 '그리고','해주시고','짜장면먹고','짜장면먹고','예뿌고','먹고','광고','라고','거라고,','알고',
                                 '라고','보고','신고','배우고','가고','여중','여고','거라고','이고','것이고','중학고','양도적고',
                                 '명문고','우리중','채우고','지나고','불고','말고','주고','입고','글고','온다고','이학교',
                                 '다니고','사용중','년중','재학중','학생중','배가고','망고']
                excluded_pattern = ['배고픈','미니학','저희','똥싸','다른','우리학','잘하는','기본','못하는','이번에','즐거운','와중',
                                    '짜장면','선생님','소중','안가는','소중','기억중','나중','그중','ㅠㅠ','로딩','ㅎㅎ','마르','택시',
                                    '역으로','예쁘','없','아침','속는','못받','못받','무시','후회','배달','더욱']
                wrong_pattern = ['진짜','으헝','일만']
                candidates = com_pattern.findall(result)
                candidates = [cdt for cdt in candidates if cdt not in excluded_word]




                if len(candidates) ==1:
                    extacted_school = candidates[0]
                    # print(candidates)
                elif len(candidates)>1:
                    ex_pattern = re.compile(''.join(map(str,[exc+'|' for exc in excluded_pattern])))
                    excluded = [''.join(map(str,ex_pattern.findall(cdt))) for cdt in candidates]
                    candidates = [candidates[idx] for idx, val in enumerate(excluded) if val =='']

                    if len(candidates)==1:
                        extacted_school = candidates[0]
                        # print(candidates)
                        # print(extacted_school)
                    elif len(candidates)>1:
                        extacted_school = top_one(candidates, base_pattern)
                        if len(extacted_school) == 1:
                            extacted_school = extacted_school[0]
                        else:
                            extacted_school = ''
                            # print(111,extacted_school,candidates)
                    else:
                        raise("this condition means that there are over-setting for excluding word to extract candidates")


                else:
                    #first, check the pattern '고'
                    high_pattern = re.compile(r"\w+?고")
                    candidates = high_pattern.findall(result)
                    candidates = [cdt for cdt in candidates if cdt not in excluded_word]
                    ex_pattern = re.compile(''.join(map(str, [exc + '|' for exc in excluded_pattern])))
                    excluded = [''.join(map(str, ex_pattern.findall(cdt))) for cdt in candidates]
                    candidates = [candidates[idx] for idx, val in enumerate(excluded) if val == '']

                    if len(candidates)==1:
                        extacted_school = candidates[0]
                    elif len(candidates) > 1 :
                        extacted_school  = top_one(candidates,base_pattern)
                        if len(extacted_school) == 1:
                            extacted_school = extacted_school[0]
                        else:
                            extacted_school = ''

                    else:
                        candidates = result.replace(' ','')
                        candidates = com_pattern.findall(candidates)
                        candidates = [cdt[max(-11,-1*len(cdt)):] for cdt in candidates]

                        extacted_school = ''
                        # print(222,line,candidates)
                        # print('111',candidates)






                queue_perfect = []
                if extacted_school in basic_school:
                    extacted_school = add_pre_word(extacted_school,result.split(' '))
                    extacted_school = remove_wrong_cha(extacted_school,wrong_pattern)
                    extacted_school = extend_postfix(extacted_school)
                    # print('111',line,extacted_school)

                else:
                    if not extacted_school == '':
                        if len(extacted_school) <= 2 or (extacted_school in basic_school or extacted_school[1:] in basic_school):
                            extacted_school = add_pre_word(extacted_school, result.split(' '))
                            extacted_school = remove_wrong_cha(extacted_school,wrong_pattern)
                            extacted_school = extend_postfix(extacted_school)
                            # print('222', line, extacted_school)
                        else:
                            extacted_school = remove_wrong_cha(extacted_school, wrong_pattern)
                            extacted_school = extend_postfix(extacted_school)


                            queue_perfect.append(extacted_school)
                            # print('000', line, extacted_school)

                    else:
                        pass
                        # extacted_school = extend_postfix(extacted_school)
                        # print('333', line, extacted_school)


            # if comment is -1:/


            except TypeError as e:
                #This comments do not include any korean words
                pass

