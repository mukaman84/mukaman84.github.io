from os import path as ops

import glob
import chardet
import sys
import pandas as pd

"""
Check the abnormality of data
1. Return a csv file path 
"""
def get_csv_file(folder=ops.dirname(ops.realpath(__file__)),file_pattern = "comments.csv"):
    """
    Return the path of given csv file pattern
    :param folder: a folder including a csv file
    :param file_pattern: a pattern to the target csv file
    :return: if one csv file is found, will return the full path of csv file.
             Otherwise, raise error with the reason
    """
    file_pattern = ops.join(folder, file_pattern)
    files = glob.glob(file_pattern)
    if len(files) > 1:
        raise ("Check the csv file. More than two csv files")
    elif len(files) == 1:
        return files[0]
    else:
        raise ("Check the csv file. No csv file")

def get_enc_type(file : str):
    """
    find the encoding type of csv file
    :param file: a full path to the csv file
    :return: an ecnding type
    """
    try:
        with open(file, "rb") as f:
            rawdata = f.read(128)
            result = chardet.detect(rawdata)
        return result['encoding']
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


def get_data(file:str, enc:str):
    args = locals()
    base_args = get_data.__annotations__.keys()


    for _k in base_args:
        if type(args[_k]) == get_data.__annotations__[_k]:
            continue
        else:
            raise TypeError(
                "The type of '{}' does not match '{}' type".format(
                    _k, get_data.__annotations__[_k]
                )
            )


    return pd.read_csv(file, encoding=enc)






