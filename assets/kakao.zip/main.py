# -*- coding: utf-8 -*-
from utilities.file_io_util import get_csv_file, get_enc_type, get_data
from utilities.find_valid_school import extract_
from os import path as ops
from queue import Queue

import numpy as np
from multiprocessing import Process, Manager
# import threading
import time

# lock = threading.Lock()

# import schedule

"""
1. pandas frame에서 하나의 frame만 추출
2. extracted frame에 서 학교 이름 추출
3. 추출된 학교 이름을 보고 학교통계 dict에 정보 추가
"""

# def get_valid_word(index,segments):
#     bisect










    # sem.release()


# class WorkingThread(threading.Thread):
#     def __init__(self,*args,**kwargs):
#         threading.Thread.__init__(self,*args,**kwargs)
#         self.input_queue = Queue()
#     def send(self,item):
#         self.input_queue.put(item)
#     def close(self,item):
#         self.input_queue.put(None)
#         self.input_queue.join()
#     def run(self):
#         while True:
#             item = self.input_queue.get()
#             if item is None:
#                 break
#             # processing items
#             print(item)
#             self.input_queue.task_done()
#         self.input_queue.task_done()
#         return

def creator(WORKER_NUMBER, data, q):
    """ Creates data to be consumed and waits for the consumer
    to finish processing """
    print('Creating data and putting it on the queue')
    for ind, item in enumerate(data):
        q.put(item)

    for _ in range(WORKER_NUMBER):
        q.put('STOP')


def main():
    # Get basic config setting to read data
    base_folder = ops.dirname(ops.realpath(__file__))
    cmt_file_path = get_csv_file(folder=base_folder, file_pattern="*comments.csv")
    enc_csv = get_enc_type(file=cmt_file_path)

    # Get comments from csv file by a pandas package
    comments = get_data(file=cmt_file_path, enc=enc_csv)
    comments = comments.values
    comments = np.squeeze(comments)

    # WORKER_NUMBER = 14

    time_list = []
    for work in range(32):
        WORKER_NUMBER = work

        manager = Manager()
        work_load_queue = manager.Queue()
        work_load_queue = manager.Queue()
        process_one = Process(target=creator, args=(WORKER_NUMBER, comments, q))

        p=[]
        for worker in range(WORKER_NUMBER):
            p.append(Process(target=extract_, args=(q,)))

        start_time = time.time()
        process_one.start()
        for worker in range(WORKER_NUMBER):
            p[worker].start()

        # q.close()
        # q.join_thread()
        # process_two = Process(target=extract_, args=(q,))
        # process_one.start()
        # process_two.start()

        process_one.join()
        for worker in range(WORKER_NUMBER):
            p[worker].join()

        end_time = time.time()
        print("#workers : {}, WorkingTime: {} sec".format(work,end_time - start_time))


        time_list.append(end_time - start_time)
    print("min work time is {:f} at # of process is {:d}".format(min(time_list),time_list.index(min(time_list))+1))
        # q.join_thread()





        # sem = threading.Semaphore(th)

        # w= WorkingThread()
        # w.start()
        # w.send()
        # w.close()




        # i = 0
        # start_time = time.time()
        # while(i<1000):
        #     # for _idx in range(8):
        #         # comment = comments[_idx]
        #
        #     if not comments[i]!=comments[i]:
        #         # extract_(i, comments[i])
        #         t = threading.Thread(target=extract_, args=(sem,i,comments[i]))
        #         t.start()
        #     else:
        #         pass
        #     i+=1
        # end_time = time.time()
        # print("WorkingTime: {} sec".format(end_time - start_time))


    # t = threading.Thread(target=extract_, args=(sem, 8, comments,))
    # t.start()







if __name__ == '__main__':
  main()